"""
Central authorization checks shared by every command and every interaction.

Premium enforcement lives here, and only here, so no command or button can
accidentally skip it. `premium_required()` is used on every feature command
(prefix + slash, since LiveBot uses hybrid commands). `guild_has_premium()`
is the equivalent helper for raw button/modal interactions, which aren't
covered by the commands framework's check system.
"""
from __future__ import annotations

import discord
from discord.ext import commands


class PremiumRequired(commands.CheckFailure):
    """Raised when a guild does not have active, valid Premium access."""


def premium_required():
    """Command check: owner always passes; otherwise the guild must have
    an active, non-expired Premium subscription."""

    async def predicate(ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage("LiveBot commands can only be used inside a server.")
        bot = ctx.bot
        if await bot.is_owner(ctx.author):
            return True
        if await bot.db.is_premium(ctx.guild.id):
            return True
        raise PremiumRequired()

    return commands.check(predicate)


async def guild_has_premium(bot: commands.Bot, guild_id: int, user: discord.abc.User) -> bool:
    """Equivalent to premium_required(), for use inside button/modal
    callbacks that aren't routed through the commands framework."""
    if await bot.is_owner(user):
        return True
    return await bot.db.is_premium(guild_id)


def is_staff():
    """Command check for ticket-staff-only actions."""

    async def predicate(ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage("LiveBot commands can only be used inside a server.")
        if await is_ticket_staff(ctx.bot, ctx.author):
            return True
        raise commands.MissingPermissions(["manage_guild"])

    return commands.check(predicate)


async def is_ticket_staff(bot: commands.Bot, member: discord.Member) -> bool:
    if await bot.is_owner(member):
        return True
    if member.guild_permissions.manage_guild:
        return True
    row = await bot.db.get_ticket_config(member.guild.id)
    staff_role_ids = set(bot.db.parse_role_ids(row["support_role_ids"]))
    return any(role.id in staff_role_ids for role in member.roles)
