"""
Central configuration for LiveBot.

Everything here is loaded from environment variables (via a local .env file
in development) so no token or secret is ever hardcoded in source.
"""
from __future__ import annotations

import os
from typing import Optional, Set

from dotenv import load_dotenv

load_dotenv()

TOKEN: Optional[str] = os.getenv("DISCORD_TOKEN")

PREFIX: str = os.getenv("COMMAND_PREFIX", "%")

_raw_owner_ids = os.getenv("OWNER_IDS", "")
OWNER_IDS: Set[int] = {
    int(value) for value in _raw_owner_ids.split(",") if value.strip().isdigit()
}

DATABASE_PATH: str = os.getenv("DATABASE_PATH", "livebot.db")

_raw_dev_guild = os.getenv("DEV_GUILD_ID", "").strip()
DEV_GUILD_ID: Optional[int] = int(_raw_dev_guild) if _raw_dev_guild.isdigit() else None

# Branding
BOT_NAME = "LiveBot"
BRAND_NAME = "Live Community"
ACTIVITY_TEXT = "Live Community"
FOOTER_TEXT = f"{BRAND_NAME} • {BOT_NAME}"

# Embed colors
COLOR_PRIMARY = 0x5865F2
COLOR_SUCCESS = 0x57F287
COLOR_ERROR = 0xED4245
COLOR_WARNING = 0xFEE75C
COLOR_PREMIUM = 0xF1C40F

# Premium plan durations in days. None means the plan never expires.
PLAN_DURATIONS = {
    "monthly": 30,
    "yearly": 365,
    "lifetime": None,
}


def validate() -> None:
    """Fail fast and clearly if required configuration is missing."""
    problems = []
    if not TOKEN:
        problems.append("DISCORD_TOKEN is not set.")
    if not OWNER_IDS:
        problems.append(
            "OWNER_IDS is not set — add at least one Discord user ID so you can "
            "manage Premium access and owner-only commands."
        )
    if problems:
        raise RuntimeError(
            "LiveBot configuration is incomplete:\n- "
            + "\n- ".join(problems)
            + "\n\nCopy .env.example to .env and fill in the required values."
        )
