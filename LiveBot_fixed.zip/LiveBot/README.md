# LiveBot

A Premium-only Discord bot for **Live Community**, built with discord.py 2.x.

## Features

- 👑 **Centralized Premium system** — monthly / yearly / lifetime plans, owner-managed, enforced by one shared check that every command and every ticket button goes through. No command bypasses it.
- 🎫 **Ticket system** — Support + Enquiry panel, private channels, claim/unclaim, close with confirmation, transcripts, open/close logs, reopen/delete controls, persistent across restarts.
- 📚 **Interactive help menu** — category dropdown + Home button, locked to the person who opened it.
- 🛠️ **Utility commands** — `ping`, `serverinfo`, `userinfo`, `avatar`, `uptime`.
- 🗄️ **SQLite persistence** (via `aiosqlite`) that survives restarts and is schema-ready for a future web dashboard.

## Project structure

```
LiveBot/
├── main.py              # Entry point: bot setup, cog loading, central error handling
├── config.py             # Loads all configuration from environment variables
├── database.py            # Async SQLite persistence layer
├── checks.py              # Central Premium / ticket-staff authorization checks
├── embeds.py              # Shared embed styling helpers
├── cogs/
│   ├── premium.py          # Owner-only Premium management + %premiumstatus
│   ├── tickets.py          # Ticket panel, claiming, closing, transcripts, logs
│   ├── help_menu.py         # Interactive %help / /help command
│   └── utility.py           # ping / serverinfo / userinfo / avatar / uptime
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

**1. Create a Discord application & bot**
- https://discord.com/developers/applications → New Application.
- Under **Bot**, click "Add Bot", then enable the **Message Content** and **Server Members** privileged intents.
- Copy the bot token — you'll need it below, and should never share it.

**2. Invite the bot to your server**
- In **OAuth2 → URL Generator**, select scopes `bot` and `applications.commands`.
- Select permissions: View Channels, Send Messages, Embed Links, Attach Files, Read Message History, Manage Channels, Manage Roles, Manage Messages.
- Open the generated URL and invite the bot.

**3. Install dependencies** (Python 3.10+ recommended)
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**4. Configure environment variables**
```bash
cp .env.example .env
```
Then edit `.env`:

| Variable | Required | Description |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | Your bot's token |
| `OWNER_IDS` | ✅ | Comma-separated Discord user ID(s) with full owner access |
| `COMMAND_PREFIX` | optional | Defaults to `%` |
| `DATABASE_PATH` | optional | Defaults to `livebot.db` |
| `DEV_GUILD_ID` | optional | Set during development to instantly sync slash commands to one server |

**5. Run the bot**
```bash
python main.py
```
`livebot.db` and all required tables are created automatically on first run.

## Granting Premium

Only users listed in `OWNER_IDS` can run these (prefix or slash — e.g. `%premium grant ...` or `/premium grant`):

- `premium grant <guild_id> <monthly|yearly|lifetime>`
- `premium revoke <guild_id>`
- `premium extend <guild_id> <days>`
- `premium info [guild_id]`
- `premium list`

`%premiumstatus` / `/premiumstatus` is available to anyone and intentionally stays outside the Premium gate, since its entire purpose is reporting status — including "not active" — for a server.

## Setting up tickets per server (requires Premium)

1. `/ticketsetup category <category>` — where ticket channels are created
2. `/ticketsetup addrole <role>` — repeat for each staff role
3. `/ticketsetup logchannel <channel>` — ticket open/close activity log
4. `/ticketsetup transcriptchannel <channel>` — where closed-ticket transcripts are posted
5. `/ticketpanel` — posts the Support/Enquiry panel in the current channel

## How Premium enforcement works

Every feature command runs through `checks.premium_required()` in `checks.py`, which:
1. Always allows the bot owner (from `OWNER_IDS`).
2. Otherwise checks the database for an active, non-expired subscription.
3. Raises one `PremiumRequired` error, caught centrally in `main.py`, which replies with a single consistent "Premium Required" embed.

Ticket buttons aren't covered by the commands framework, so each button callback calls the same underlying `checks.guild_has_premium()` helper directly before doing anything — covering the brief's explicit requirement that Premium can't be bypassed through buttons, modals, slash commands, or prefix commands.

Owner-only Premium management commands (`premium grant/revoke/extend/info/list`) are gated purely by `commands.is_owner()`, not by the Premium check itself — otherwise the owner couldn't grant Premium to a brand-new server that doesn't have it yet.

## About the website dashboard

No dashboard or payment backend is included — the brief asked for the bot to be *prepared* for one (section 8), not for one to be built, and this delivery doesn't pretend otherwise. What's actually in place:

- `database.py` keeps Premium, ticket configuration, and ticket records in separate tables keyed by `guild_id`, so a future web backend can read/write the same data without a redesign.
- All mutations go through typed `Database` methods rather than ad-hoc SQL in cogs, so an API layer can reuse them directly.
- `config.py` is the only place secrets are read from, and only from environment variables — nothing a frontend could ever reach references the token directly.

Building the OAuth2 flow, an API server, and payment integration is a separate project.

## Testing notes — please read

This was written and reviewed in a sandboxed environment with **no network access and no real Discord bot token**, so it could not be connected to the live Discord gateway for an end-to-end run. What was actually verified:

- Every file passes `python -m py_compile` (no syntax errors).
- Manual review of every command, check, and view against discord.py 2.x's documented behavior for hybrid commands, persistent views, and interactions.

What to verify yourself once you add a real token (mirroring the brief's test checklist):

- [ ] Bot connects and shows **Watching Live Community**
- [ ] `%ping` / `/ping` work once Premium is granted to your test server
- [ ] `%premium grant <guild_id> monthly` (and `yearly`, `lifetime`) works, and commands unlock immediately
- [ ] Commands are blocked with the Premium Required embed in a non-Premium server
- [ ] `%premium revoke <guild_id>` immediately re-locks the server
- [ ] A non-owner running `%premium grant ...` is rejected
- [ ] `/ticketpanel` → Support/Enquiry buttons create a private channel
- [ ] Claim ↔ Unclaim toggle works; Close → Confirm → transcript posted → channel locked → Reopen restores access
- [ ] Opening a second ticket of the same type is blocked
- [ ] `/help` navigates between categories and only the invoking user can use its buttons
- [ ] Restart the bot — old ticket panel and in-ticket buttons still work
- [ ] Restart the bot — Premium status and ticket records are unchanged

If anything on this list doesn't behave as expected, let me know what happened and it can be fixed.

## Validation and deployment checklist

The source has been syntax-compiled with Python. This is not the same as a live Discord test. Before production use:

1. Install dependencies with `python -m pip install -r requirements.txt`.
2. Copy `.env.example` to `.env` and set a real `DISCORD_TOKEN` and your Discord user ID in `OWNER_IDS`. Never upload `.env` or share the token.
3. In the Discord Developer Portal, enable **Message Content Intent** and **Server Members Intent** if you use prefix commands/member lookups. Invite the bot with the application-command scope and the permissions needed to manage ticket channels and messages.
4. Start with `python main.py` and confirm all required cogs load and the database path is persistent on the host.
5. Test owner-only Premium grant/revoke/extend/list/info with a test server; test monthly/yearly expiry and lifetime access.
6. Test ticket creation, duplicate prevention, staff claim/unclaim, close confirmation, transcript delivery, reopen and delete with a non-owner test account.
7. Verify slash commands are synced. Global slash-command changes may take time to propagate; `DEV_GUILD_ID` can be set temporarily for quick development sync.

The code has not been connected to a live Discord bot from this environment, so Discord permissions, API behaviour, and full end-to-end workflows still need to be verified on your server.

