"""Shared embed builders so every LiveBot reply looks consistent and on-brand."""
from __future__ import annotations

import datetime
from typing import Optional

import discord

import config


def _base(color: int, title: Optional[str], description: Optional[str]) -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.datetime.now(datetime.timezone.utc),
    )
    embed.set_footer(text=config.FOOTER_TEXT)
    return embed


def info_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    return _base(config.COLOR_PRIMARY, title, description)


def success_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    return _base(config.COLOR_SUCCESS, f"✅ {title}", description)


def error_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    return _base(config.COLOR_ERROR, f"⚠️ {title}", description)


def warning_embed(title: str, description: Optional[str] = None) -> discord.Embed:
    return _base(config.COLOR_WARNING, f"⚠️ {title}", description)


def premium_required_embed() -> discord.Embed:
    return _base(
        config.COLOR_PREMIUM,
        "🔒 Premium Required",
        (
            f"**{config.BOT_NAME}** is a Premium-only bot for **{config.BRAND_NAME}** — "
            "this server doesn't have active Premium access, so this feature is locked.\n\n"
            "Ask a server admin to contact the LiveBot owner about Premium "
            "(monthly, yearly, or lifetime plans)."
        ),
    )
