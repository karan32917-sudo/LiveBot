"""Interactive, button-driven %help / /help command."""
from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import discord
from discord.ext import commands

import checks
import config
import embeds

logger = logging.getLogger("livebot.help")

# (command name, description, usage) per category. Only commands that are
# actually implemented elsewhere in the bot are listed here.
CATEGORIES: Dict[str, Dict[str, object]] = {
    "utility": {
        "label": "Utility",
        "emoji": "🛠️",
        "description": "General-purpose tools available to every Premium server.",
        "commands": [
            ("ping", "Check LiveBot's latency and connection status.", "%ping · /ping"),
            ("serverinfo", "Show information about this server.", "%serverinfo · /serverinfo"),
            ("userinfo", "Show information about a user.", "%userinfo [user] · /userinfo [user]"),
            ("avatar", "Display a user's avatar.", "%avatar [user] · /avatar [user]"),
            ("uptime", "Show how long LiveBot has been online.", "%uptime · /uptime"),
        ],
    },
    "tickets": {
        "label": "Tickets",
        "emoji": "🎫",
        "description": "LiveBot's support ticket system (requires Manage Server to configure).",
        "commands": [
            ("ticketpanel", "Post the interactive ticket panel in this channel.", "%ticketpanel · /ticketpanel"),
            ("ticketsetup category", "Set the category new ticket channels are created under.", "/ticketsetup category <category>"),
            ("ticketsetup addrole", "Add a staff role that can manage tickets.", "/ticketsetup addrole <role>"),
            ("ticketsetup removerole", "Remove a staff role.", "/ticketsetup removerole <role>"),
            ("ticketsetup logchannel", "Set the channel ticket open/close logs are sent to.", "/ticketsetup logchannel <channel>"),
            ("ticketsetup transcriptchannel", "Set the channel ticket transcripts are sent to.", "/ticketsetup transcriptchannel <channel>"),
            ("ticketsetup show", "Show the current ticket configuration.", "%ticketsetup show · /ticketsetup show"),
        ],
    },
    "premium": {
        "label": "Premium",
        "emoji": "👑",
        "description": "Check this server's Premium subscription.",
        "commands": [
            ("premiumstatus", "Show this server's Premium plan and expiry.", "%premiumstatus · /premiumstatus"),
        ],
    },
    "owner": {
        "label": "Owner",
        "emoji": "🔑",
        "description": "Restricted to the LiveBot owner.",
        "commands": [
            ("premium grant", "Grant Premium access to a server.", "%premium grant <guild_id> <plan>"),
            ("premium revoke", "Revoke Premium access from a server.", "%premium revoke <guild_id>"),
            ("premium extend", "Extend a server's Premium subscription.", "%premium extend <guild_id> <days>"),
            ("premium info", "Inspect any server's Premium status.", "%premium info [guild_id]"),
            ("premium list", "List every server with active Premium.", "%premium list"),
        ],
    },
}


def build_home_embed(is_owner: bool) -> discord.Embed:
    embed = embeds.info_embed(
        f"📚 {config.BOT_NAME} Help Menu",
        "Select a category from the dropdown below to see its commands.\nUse **Home** at any time to come back here.",
    )
    for key, cat in CATEGORIES.items():
        if key == "owner" and not is_owner:
            continue
        embed.add_field(name=f"{cat['emoji']} {cat['label']}", value=cat["description"], inline=False)
    return embed


def build_category_embed(key: str) -> discord.Embed:
    cat = CATEGORIES[key]
    embed = embeds.info_embed(f"{cat['emoji']} {cat['label']} Commands", cat["description"])
    commands_list: List[Tuple[str, str, str]] = cat["commands"]  # type: ignore[assignment]
    for name, desc, usage in commands_list:
        embed.add_field(name=f"`{name}`", value=f"{desc}\n**Usage:** `{usage}`", inline=False)
    return embed


class _BaseHelpItem:
    async def _reject_if_not_owner(self, interaction: discord.Interaction, author_id: int) -> bool:
        if interaction.user.id != author_id:
            await interaction.response.send_message(
                embed=embeds.error_embed("Not Your Menu", "Only the person who ran this command can use it."),
                ephemeral=True,
            )
            return True
        return False


class CategorySelect(discord.ui.Select, _BaseHelpItem):
    def __init__(self, view: "HelpView") -> None:
        self.help_view = view
        options = [
            discord.SelectOption(label=cat["label"], value=key, emoji=cat["emoji"], description=str(cat["description"])[:100])
            for key, cat in CATEGORIES.items()
            if key != "owner" or view.is_owner
        ]
        super().__init__(placeholder="Choose a category...", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction) -> None:
        if await self._reject_if_not_owner(interaction, self.help_view.author_id):
            return
        await interaction.response.edit_message(embed=build_category_embed(self.values[0]), view=self.help_view)


class HomeButton(discord.ui.Button, _BaseHelpItem):
    def __init__(self, view: "HelpView") -> None:
        super().__init__(label="Home", emoji="🏠", style=discord.ButtonStyle.secondary, row=1)
        self.help_view = view

    async def callback(self, interaction: discord.Interaction) -> None:
        if await self._reject_if_not_owner(interaction, self.help_view.author_id):
            return
        await interaction.response.edit_message(embed=build_home_embed(self.help_view.is_owner), view=self.help_view)


class HelpView(discord.ui.View):
    def __init__(self, author_id: int, is_owner: bool) -> None:
        super().__init__(timeout=120)
        self.author_id = author_id
        self.is_owner = is_owner
        self.message: discord.Message | None = None
        self.add_item(CategorySelect(self))
        self.add_item(HomeButton(self))

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True  # type: ignore[attr-defined]
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        logger.exception("Error handling help menu interaction", exc_info=error)
        message = "Something went wrong opening that menu. Please run the help command again."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embeds.error_embed("Unexpected Error", message), ephemeral=True)
            else:
                await interaction.response.send_message(embed=embeds.error_embed("Unexpected Error", message), ephemeral=True)
        except discord.HTTPException:
            pass


class HelpMenu(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.hybrid_command(name="help", description="Open LiveBot's interactive help menu.")
    @checks.premium_required()
    async def help_command(self, ctx: commands.Context) -> None:
        is_owner = await self.bot.is_owner(ctx.author)
        view = HelpView(author_id=ctx.author.id, is_owner=is_owner)
        message = await ctx.send(embed=build_home_embed(is_owner), view=view)
        view.message = message


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(HelpMenu(bot))
