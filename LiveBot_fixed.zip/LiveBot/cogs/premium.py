"""
Owner-only Premium management system.

This cog is the single place subscriptions are granted, revoked, extended
and inspected. Every other part of the bot (commands and ticket buttons
alike) only ever calls Database.is_premium() / checks.premium_required() —
never its own copy of this logic — so enforcement can't drift out of sync.
"""
from __future__ import annotations

import datetime
import logging
from typing import Literal, Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
import embeds

logger = logging.getLogger("livebot.premium")

PlanLiteral = Literal["monthly", "yearly", "lifetime"]


def _format_expiry(expires_at: Optional[str]) -> str:
    if expires_at is None:
        return "Never (Lifetime)"
    timestamp = int(datetime.datetime.fromisoformat(expires_at).timestamp())
    return f"<t:{timestamp}:F> (<t:{timestamp}:R>)"


class Premium(commands.Cog):
    """Premium subscription management."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # %premium / premium <subcommand> — owner only
    # ------------------------------------------------------------------

    @commands.hybrid_group(name="premium", description="Owner-only Premium management commands.")
    async def premium_cmd(self, ctx: commands.Context) -> None:
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @premium_cmd.command(name="grant", description="Grant Premium access to a server.")
    @app_commands.describe(guild_id="The server ID to grant Premium to", plan="Subscription plan")
    @commands.is_owner()
    async def grant(self, ctx: commands.Context, guild_id: str, plan: PlanLiteral) -> None:
        if not guild_id.isdigit():
            await ctx.send(embed=embeds.error_embed("Invalid Server ID", "Server IDs are numeric."))
            return
        days = config.PLAN_DURATIONS[plan]
        record = await self.bot.db.grant_premium(
            guild_id=int(guild_id), plan=plan, granted_by=ctx.author.id, days=days
        )
        logger.info("Premium granted to guild %s (%s) by %s", guild_id, plan, ctx.author.id)
        embed = embeds.success_embed(
            "Premium Granted",
            f"Server `{guild_id}` now has **{plan.title()}** Premium.\n"
            f"Expires: {_format_expiry(record.expires_at)}",
        )
        await ctx.send(embed=embed)

    @premium_cmd.command(name="revoke", description="Revoke Premium access from a server.")
    @app_commands.describe(guild_id="The server ID to revoke Premium from")
    @commands.is_owner()
    async def revoke(self, ctx: commands.Context, guild_id: str) -> None:
        if not guild_id.isdigit():
            await ctx.send(embed=embeds.error_embed("Invalid Server ID", "Server IDs are numeric."))
            return
        revoked = await self.bot.db.revoke_premium(int(guild_id))
        if revoked:
            logger.info("Premium revoked for guild %s by %s", guild_id, ctx.author.id)
            await ctx.send(
                embed=embeds.success_embed("Premium Revoked", f"Server `{guild_id}` no longer has Premium access.")
            )
        else:
            await ctx.send(embed=embeds.error_embed("Not Found", f"Server `{guild_id}` has no Premium record."))

    @premium_cmd.command(name="extend", description="Extend a server's Premium subscription.")
    @app_commands.describe(guild_id="The server ID to extend", days="Number of days to add")
    @commands.is_owner()
    async def extend(self, ctx: commands.Context, guild_id: str, days: int) -> None:
        if not guild_id.isdigit():
            await ctx.send(embed=embeds.error_embed("Invalid Server ID", "Server IDs are numeric."))
            return
        if days <= 0:
            await ctx.send(embed=embeds.error_embed("Invalid Duration", "Days must be a positive number."))
            return
        record = await self.bot.db.extend_premium(int(guild_id), days)
        if record is None:
            await ctx.send(
                embed=embeds.error_embed("Not Found", f"Server `{guild_id}` has no Premium record to extend.")
            )
            return
        logger.info("Premium extended for guild %s by %s days (%s)", guild_id, days, ctx.author.id)
        await ctx.send(
            embed=embeds.success_embed(
                "Premium Extended", f"Server `{guild_id}` now expires: {_format_expiry(record.expires_at)}"
            )
        )

    @premium_cmd.command(name="info", description="Inspect a server's Premium status.")
    @app_commands.describe(guild_id="The server ID to inspect (defaults to this server)")
    @commands.is_owner()
    async def info(self, ctx: commands.Context, guild_id: Optional[str] = None) -> None:
        if guild_id is not None and not guild_id.isdigit():
            await ctx.send(embed=embeds.error_embed("Invalid Server ID", "Server IDs must contain digits only."))
            return
        target_id = int(guild_id) if guild_id else (ctx.guild.id if ctx.guild else None)
        if target_id is None:
            await ctx.send(embed=embeds.error_embed("Missing Server ID", "Provide a server ID or run this inside a server."))
            return
        await ctx.send(embed=await self._build_status_embed(target_id))

    @premium_cmd.command(name="list", description="List every server with active Premium.")
    @commands.is_owner()
    async def list_premium(self, ctx: commands.Context) -> None:
        records = await self.bot.db.all_premium_guilds()
        if not records:
            await ctx.send(embed=embeds.info_embed("Premium Servers", "No servers currently have active Premium."))
            return
        lines = []
        for record in records:
            guild = self.bot.get_guild(record.guild_id)
            name = guild.name if guild else f"Unknown server ({record.guild_id})"
            expiry = "Lifetime" if record.is_lifetime else f"<t:{int(datetime.datetime.fromisoformat(record.expires_at).timestamp())}:R>"
            lines.append(f"**{name}** — `{record.guild_id}` — {record.plan.title()} — expires {expiry}")
        # Discord embed descriptions are limited to 4,096 characters. Split
        # large owner listings into multiple messages rather than failing.
        chunks = []
        current = []
        current_length = 0
        for line in lines:
            if current and current_length + len(line) + 1 > 3800:
                chunks.append("\n".join(current))
                current, current_length = [], 0
            current.append(line)
            current_length += len(line) + 1
        if current:
            chunks.append("\n".join(current))
        for index, chunk in enumerate(chunks, start=1):
            title = "Active Premium Servers" if len(chunks) == 1 else f"Active Premium Servers ({index}/{len(chunks)})"
            await ctx.send(embed=embeds.info_embed(title, chunk))

    # ------------------------------------------------------------------
    # %premiumstatus — available to everyone, Premium or not. This is the
    # one command intentionally left outside the Premium gate, since its
    # entire purpose is to report status (including "none" / "expired").
    # ------------------------------------------------------------------

    @commands.hybrid_command(name="premiumstatus", description="Show this server's Premium plan and expiry.")
    async def premiumstatus(self, ctx: commands.Context) -> None:
        if ctx.guild is None:
            await ctx.send(embed=embeds.error_embed("Server Only", "Run this inside a server."))
            return
        await ctx.send(embed=await self._build_status_embed(ctx.guild.id))

    async def _build_status_embed(self, guild_id: int) -> discord.Embed:
        record = await self.bot.db.get_premium(guild_id)
        active = await self.bot.db.is_premium(guild_id)
        if record is None:
            return embeds.premium_required_embed()
        if not active:
            embed = embeds.premium_required_embed()
            embed.add_field(name="Previous Plan", value=record.plan.title(), inline=True)
            embed.add_field(name="Status", value="Expired / Inactive", inline=True)
            return embed
        embed = embeds.success_embed("Premium Active", f"This server has active **{record.plan.title()}** Premium.")
        embed.add_field(name="Plan", value=record.plan.title(), inline=True)
        embed.add_field(name="Expires", value=_format_expiry(record.expires_at), inline=True)
        return embed

    # ------------------------------------------------------------------
    # Error handling for the owner-only subcommands
    # ------------------------------------------------------------------

    @grant.error
    @revoke.error
    @extend.error
    @info.error
    @list_premium.error
    async def owner_only_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, commands.NotOwner):
            await ctx.send(embed=embeds.error_embed("Owner Only", "Only the LiveBot owner can use this command."))
        else:
            raise error


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Premium(bot))
