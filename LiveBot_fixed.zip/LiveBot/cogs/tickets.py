"""
Advanced ticket system.

- An interactive panel (Support / Enquiry buttons) that creates a private
  channel per ticket.
- Claim / unclaim, close with confirmation, reopen, and permanent delete.
- Transcripts posted to a configurable channel; open/close events logged
  to a configurable log channel.
- All persistent views (panel, in-ticket controls, closed-ticket controls)
  are registered with static custom_ids in `setup()` below so buttons keep
  working after a restart, without needing the original message.
- Every entry point — commands *and* every button callback — checks
  Premium status itself via checks.guild_has_premium(), since button
  interactions aren't covered by the commands framework's check system.
"""
from __future__ import annotations

import io
import logging
from typing import Dict, Set

import discord
from discord import app_commands
from discord.ext import commands

import checks
import config
import embeds

logger = logging.getLogger("livebot.tickets")

TICKET_TYPES: Dict[str, Dict[str, str]] = {
    "support": {"label": "Support", "emoji": "🛟"},
    "enquiry": {"label": "Enquiry", "emoji": "❓"},
}


def _channel_safe_name(user: discord.abc.User, ticket_type: str, number: int) -> str:
    base = f"{ticket_type}-{number:04d}-{user.name}"
    return base[:95].lower().replace(" ", "-")


async def _build_overwrites(
    guild: discord.Guild, opener: discord.Member, staff_role_ids: Set[int]
) -> dict:
    overwrites: dict = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        guild.me: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, manage_channels=True, read_message_history=True
        ),
        opener: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True, attach_files=True
        ),
    }
    for role_id in staff_role_ids:
        role = guild.get_role(role_id)
        if role is not None:
            overwrites[role] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True, manage_messages=True
            )
    return overwrites


async def _generate_transcript(channel: discord.TextChannel) -> discord.File:
    lines = [f"Transcript for #{channel.name} ({channel.id})", "=" * 60]
    async for message in channel.history(limit=None, oldest_first=True):
        timestamp = message.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        content = message.content or "[no text content]"
        lines.append(f"[{timestamp}] {message.author} ({message.author.id}): {content}")
        for attachment in message.attachments:
            lines.append(f"    [attachment] {attachment.filename}: {attachment.url}")
    buffer = io.BytesIO("\n".join(lines).encode("utf-8"))
    return discord.File(buffer, filename=f"transcript-{channel.name}.txt")


class _BaseTicketView(discord.ui.View):
    """Shared graceful-error-handling for every ticket view."""

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        logger.exception("Error handling ticket interaction", exc_info=error)
        message = "Something went wrong handling that action. Please try again or contact staff."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embeds.error_embed("Unexpected Error", message), ephemeral=True)
            else:
                await interaction.response.send_message(
                    embed=embeds.error_embed("Unexpected Error", message), ephemeral=True
                )
        except discord.HTTPException:
            pass


class CloseConfirmView(_BaseTicketView):
    def __init__(self, cog: "Tickets", author_id: int) -> None:
        super().__init__(timeout=60)
        self.cog = cog
        self.author_id = author_id

    @discord.ui.button(label="Confirm Close", style=discord.ButtonStyle.danger, emoji="✅")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                embed=embeds.error_embed("Not For You", "Only the person who clicked Close can confirm this."),
                ephemeral=True,
            )
            return
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        await self.cog.finalize_close(interaction)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, emoji="✖️")
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                embed=embeds.error_embed("Not For You", "Only the person who clicked Close can cancel this."),
                ephemeral=True,
            )
            return
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=embeds.info_embed("Cancelled", "This ticket will remain open."), view=self
        )


class TicketPanelView(_BaseTicketView):
    """Posted once per server; buttons survive restarts via static custom_id."""

    def __init__(self, cog: "Tickets") -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Support", emoji="🛟", style=discord.ButtonStyle.primary, custom_id="livebot:ticket_open:support"
    )
    async def open_support(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.open_ticket(interaction, "support")

    @discord.ui.button(
        label="Enquiry", emoji="❓", style=discord.ButtonStyle.secondary, custom_id="livebot:ticket_open:enquiry"
    )
    async def open_enquiry(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.open_ticket(interaction, "enquiry")


class TicketControlView(_BaseTicketView):
    """Posted inside every open ticket channel; persistent across restarts."""

    def __init__(self, cog: "Tickets") -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Claim", emoji="🙋", style=discord.ButtonStyle.success, custom_id="livebot:ticket_claim_toggle"
    )
    async def claim_toggle(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.toggle_claim(interaction)

    @discord.ui.button(label="Close", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="livebot:ticket_close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.request_close(interaction)


class ClosedTicketView(_BaseTicketView):
    """Posted after a ticket closes; lets staff reopen or permanently delete it."""

    def __init__(self, cog: "Tickets") -> None:
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Reopen", emoji="🔓", style=discord.ButtonStyle.success, custom_id="livebot:ticket_reopen"
    )
    async def reopen(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.reopen_ticket(interaction)

    @discord.ui.button(label="Delete", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id="livebot:ticket_delete")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.cog.delete_ticket(interaction)


class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # Configuration commands (admin + Premium required)
    # ------------------------------------------------------------------

    @commands.hybrid_group(name="ticketsetup", description="Configure LiveBot's ticket system.")
    async def ticketsetup(self, ctx: commands.Context) -> None:
        if ctx.invoked_subcommand is None:
            await ctx.send_help(ctx.command)

    @ticketsetup.command(name="category", description="Set the category new tickets are created under.")
    @app_commands.describe(category="The category ticket channels should be created in")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def set_category(self, ctx: commands.Context, category: discord.CategoryChannel) -> None:
        await self.bot.db.set_ticket_category(ctx.guild.id, category.id)
        await ctx.send(embed=embeds.success_embed("Ticket Category Set", f"New tickets will be created under **{category.name}**."))

    @ticketsetup.command(name="addrole", description="Add a staff role that can manage tickets.")
    @app_commands.describe(role="The role to grant ticket-staff access to")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def add_role(self, ctx: commands.Context, role: discord.Role) -> None:
        await self.bot.db.add_support_role(ctx.guild.id, role.id)
        await ctx.send(embed=embeds.success_embed("Staff Role Added", f"{role.mention} can now claim and manage tickets."))

    @ticketsetup.command(name="removerole", description="Remove a ticket staff role.")
    @app_commands.describe(role="The role to remove")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def remove_role(self, ctx: commands.Context, role: discord.Role) -> None:
        await self.bot.db.remove_support_role(ctx.guild.id, role.id)
        await ctx.send(embed=embeds.success_embed("Staff Role Removed", f"{role.mention} no longer has ticket-staff access."))

    @ticketsetup.command(name="logchannel", description="Set the channel ticket open/close logs are sent to.")
    @app_commands.describe(channel="The log channel")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def set_log_channel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        await self.bot.db.set_log_channel(ctx.guild.id, channel.id)
        await ctx.send(embed=embeds.success_embed("Log Channel Set", f"Ticket logs will be sent to {channel.mention}."))

    @ticketsetup.command(name="transcriptchannel", description="Set the channel ticket transcripts are sent to.")
    @app_commands.describe(channel="The transcript channel")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def set_transcript_channel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        await self.bot.db.set_transcript_channel(ctx.guild.id, channel.id)
        await ctx.send(embed=embeds.success_embed("Transcript Channel Set", f"Transcripts will be sent to {channel.mention}."))

    @ticketsetup.command(name="show", description="Show the current ticket configuration.")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def show_config(self, ctx: commands.Context) -> None:
        row = await self.bot.db.get_ticket_config(ctx.guild.id)
        category = ctx.guild.get_channel(row["category_id"]) if row["category_id"] else None
        log_channel = ctx.guild.get_channel(row["log_channel_id"]) if row["log_channel_id"] else None
        transcript_channel = ctx.guild.get_channel(row["transcript_channel_id"]) if row["transcript_channel_id"] else None
        roles = [ctx.guild.get_role(r) for r in self.bot.db.parse_role_ids(row["support_role_ids"])]
        roles_text = ", ".join(r.mention for r in roles if r is not None) or "None set"

        embed = embeds.info_embed("🎫 Ticket Configuration")
        embed.add_field(name="Category", value=category.mention if category else "Not set", inline=True)
        embed.add_field(name="Log Channel", value=log_channel.mention if log_channel else "Not set", inline=True)
        embed.add_field(
            name="Transcript Channel", value=transcript_channel.mention if transcript_channel else "Not set", inline=True
        )
        embed.add_field(name="Staff Roles", value=roles_text, inline=False)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="ticketpanel", description="Post the interactive ticket panel in this channel.")
    @commands.has_permissions(manage_guild=True)
    @checks.premium_required()
    async def ticketpanel(self, ctx: commands.Context) -> None:
        embed = embeds.info_embed(
            f"🎫 {config.BRAND_NAME} Support",
            "Need help or have a question? Open a ticket below and our team will assist you.\n\n"
            "🛟 **Support** — technical issues or account help\n"
            "❓ **Enquiry** — general questions",
        )
        message = await ctx.send(embed=embed, view=TicketPanelView(self))
        await self.bot.db.set_panel_message(ctx.guild.id, message.channel.id, message.id)

    # ------------------------------------------------------------------
    # Button-driven ticket flow
    # ------------------------------------------------------------------

    async def open_ticket(self, interaction: discord.Interaction, ticket_type: str) -> None:
        guild = interaction.guild
        member = interaction.user
        assert guild is not None and isinstance(member, discord.Member)

        if not await checks.guild_has_premium(self.bot, guild.id, member):
            await interaction.response.send_message(embed=embeds.premium_required_embed(), ephemeral=True)
            return

        existing = await self.bot.db.get_open_ticket_for_user(guild.id, member.id, ticket_type)
        if existing is not None:
            channel = guild.get_channel(existing.channel_id)
            mention = channel.mention if channel else f"`#{existing.channel_id}`"
            await interaction.response.send_message(
                embed=embeds.error_embed("Ticket Already Open", f"You already have an open {ticket_type} ticket: {mention}"),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        row = await self.bot.db.get_ticket_config(guild.id)
        category = guild.get_channel(row["category_id"]) if row["category_id"] else None
        staff_role_ids = set(self.bot.db.parse_role_ids(row["support_role_ids"]))
        overwrites = await _build_overwrites(guild, member, staff_role_ids)
        number = await self.bot.db.next_ticket_number(guild.id)
        channel_name = _channel_safe_name(member, ticket_type, number)

        try:
            channel = await guild.create_text_channel(
                name=channel_name,
                category=category if isinstance(category, discord.CategoryChannel) else None,
                overwrites=overwrites,
                reason=f"{ticket_type.title()} ticket opened by {member}",
            )
        except discord.Forbidden:
            await interaction.followup.send(
                embed=embeds.error_embed("Missing Permissions", "I don't have permission to create ticket channels here."),
                ephemeral=True,
            )
            return

        await self.bot.db.create_ticket(guild.id, channel.id, member.id, ticket_type)

        meta = TICKET_TYPES[ticket_type]
        embed = embeds.info_embed(
            f"{meta['emoji']} {meta['label']} Ticket",
            f"Hello {member.mention}! Thanks for reaching out. A staff member will be with you shortly.\n\n"
            "Please describe your issue in as much detail as possible.",
        )
        await channel.send(content=member.mention, embed=embed, view=TicketControlView(self))

        await interaction.followup.send(
            embed=embeds.success_embed("Ticket Created", f"Your ticket has been created: {channel.mention}"), ephemeral=True
        )
        logger.info("Ticket #%s (%s) opened by %s in guild %s", number, ticket_type, member.id, guild.id)
        await self._log(guild, embeds.info_embed("🎫 Ticket Opened", f"{member.mention} opened a **{ticket_type}** ticket: {channel.mention}"))

    async def toggle_claim(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user
        assert guild is not None and isinstance(member, discord.Member)

        if not await checks.guild_has_premium(self.bot, guild.id, member):
            await interaction.response.send_message(embed=embeds.premium_required_embed(), ephemeral=True)
            return
        if not await checks.is_ticket_staff(self.bot, member):
            await interaction.response.send_message(
                embed=embeds.error_embed("Staff Only", "Only ticket staff can claim this ticket."), ephemeral=True
            )
            return

        ticket = await self.bot.db.get_ticket_by_channel(interaction.channel_id)
        if ticket is None or ticket.status == "closed":
            await interaction.response.send_message(
                embed=embeds.error_embed("Not a Ticket", "This isn't an open ticket channel."), ephemeral=True
            )
            return

        if ticket.status == "claimed":
            await self.bot.db.unclaim_ticket(interaction.channel_id)
            await interaction.response.send_message(embed=embeds.info_embed("Ticket Unclaimed", f"{member.mention} unclaimed this ticket."))
        else:
            await self.bot.db.claim_ticket(interaction.channel_id, member.id)
            await interaction.response.send_message(
                embed=embeds.success_embed("Ticket Claimed", f"{member.mention} is now handling this ticket.")
            )

    async def request_close(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user
        assert guild is not None and isinstance(member, discord.Member)

        if not await checks.guild_has_premium(self.bot, guild.id, member):
            await interaction.response.send_message(embed=embeds.premium_required_embed(), ephemeral=True)
            return

        ticket = await self.bot.db.get_ticket_by_channel(interaction.channel_id)
        if ticket is None or ticket.status == "closed":
            await interaction.response.send_message(
                embed=embeds.error_embed("Not a Ticket", "This isn't an open ticket channel."), ephemeral=True
            )
            return

        is_staff = await checks.is_ticket_staff(self.bot, member)
        if member.id != ticket.user_id and not is_staff:
            await interaction.response.send_message(
                embed=embeds.error_embed("Not Allowed", "Only the ticket opener or staff can close this ticket."),
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            embed=embeds.warning_embed(
                "Close Ticket?", "Are you sure you want to close this ticket? You can reopen it until it's deleted."
            ),
            view=CloseConfirmView(self, author_id=member.id),
        )

    async def finalize_close(self, interaction: discord.Interaction) -> None:
        channel = interaction.channel
        guild = interaction.guild
        assert isinstance(channel, discord.TextChannel) and guild is not None

        ticket = await self.bot.db.get_ticket_by_channel(channel.id)
        if ticket is None:
            return
        await self.bot.db.close_ticket(channel.id, interaction.user.id)

        transcript = await _generate_transcript(channel)
        row = await self.bot.db.get_ticket_config(guild.id)
        transcript_channel = guild.get_channel(row["transcript_channel_id"]) if row["transcript_channel_id"] else None
        if isinstance(transcript_channel, discord.TextChannel):
            try:
                await transcript_channel.send(
                    embed=embeds.info_embed(
                        "📄 Ticket Transcript", f"Transcript for #{channel.name} (closed by {interaction.user.mention})"
                    ),
                    file=transcript,
                )
            except discord.HTTPException:
                logger.warning("Failed to deliver transcript for channel %s", channel.id)

        opener = guild.get_member(ticket.user_id)
        if opener is not None:
            overwrite = channel.overwrites_for(opener)
            overwrite.send_messages = False
            await channel.set_permissions(opener, overwrite=overwrite, reason="Ticket closed")

        if not channel.name.startswith("closed-"):
            try:
                await channel.edit(name=f"closed-{channel.name}"[:95])
            except discord.HTTPException:
                pass

        await channel.send(
            embed=embeds.info_embed("🔒 Ticket Closed", f"This ticket was closed by {interaction.user.mention}."),
            view=ClosedTicketView(self),
        )
        logger.info("Ticket in channel %s closed by %s", channel.id, interaction.user.id)
        await self._log(guild, embeds.info_embed("🔒 Ticket Closed", f"{interaction.user.mention} closed ticket {channel.mention}"))

    async def reopen_ticket(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user
        channel = interaction.channel
        assert guild is not None and isinstance(member, discord.Member) and isinstance(channel, discord.TextChannel)

        if not await checks.guild_has_premium(self.bot, guild.id, member):
            await interaction.response.send_message(embed=embeds.premium_required_embed(), ephemeral=True)
            return
        if not await checks.is_ticket_staff(self.bot, member):
            await interaction.response.send_message(
                embed=embeds.error_embed("Staff Only", "Only ticket staff can reopen a ticket."), ephemeral=True
            )
            return

        ticket = await self.bot.db.get_ticket_by_channel(channel.id)
        if ticket is None:
            await interaction.response.send_message(embed=embeds.error_embed("Not a Ticket", "This isn't a ticket channel."), ephemeral=True)
            return

        await self.bot.db.reopen_ticket(channel.id)
        opener = guild.get_member(ticket.user_id)
        if opener is not None:
            overwrite = channel.overwrites_for(opener)
            overwrite.send_messages = True
            overwrite.view_channel = True
            await channel.set_permissions(opener, overwrite=overwrite, reason="Ticket reopened")

        new_name = channel.name[len("closed-"):] if channel.name.startswith("closed-") else channel.name
        try:
            await channel.edit(name=new_name[:95])
        except discord.HTTPException:
            pass

        await interaction.response.send_message(
            embed=embeds.success_embed("Ticket Reopened", f"{member.mention} reopened this ticket."),
            view=TicketControlView(self),
        )
        logger.info("Ticket in channel %s reopened by %s", channel.id, member.id)
        await self._log(guild, embeds.info_embed("🔓 Ticket Reopened", f"{member.mention} reopened ticket {channel.mention}"))

    async def delete_ticket(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user
        channel = interaction.channel
        assert guild is not None and isinstance(member, discord.Member) and isinstance(channel, discord.TextChannel)

        if not await checks.guild_has_premium(self.bot, guild.id, member):
            await interaction.response.send_message(embed=embeds.premium_required_embed(), ephemeral=True)
            return
        if not await checks.is_ticket_staff(self.bot, member):
            await interaction.response.send_message(
                embed=embeds.error_embed("Staff Only", "Only ticket staff can permanently delete a ticket."),
                ephemeral=True,
            )
            return

        await interaction.response.send_message(embed=embeds.info_embed("Deleting...", "This channel will be deleted shortly."))
        logger.info("Ticket channel %s deleted by %s", channel.id, member.id)
        await self._log(guild, embeds.info_embed("🗑️ Ticket Deleted", f"{member.mention} deleted ticket #{channel.name}"))
        try:
            await channel.delete(reason=f"Ticket deleted by {member}")
        except discord.HTTPException:
            pass

    async def _log(self, guild: discord.Guild, embed: discord.Embed) -> None:
        row = await self.bot.db.get_ticket_config(guild.id)
        log_channel = guild.get_channel(row["log_channel_id"]) if row["log_channel_id"] else None
        if isinstance(log_channel, discord.TextChannel):
            try:
                await log_channel.send(embed=embed)
            except discord.HTTPException:
                pass

    # ------------------------------------------------------------------
    # Error handling for the admin configuration commands
    # ------------------------------------------------------------------

    @set_category.error
    @add_role.error
    @remove_role.error
    @set_log_channel.error
    @set_transcript_channel.error
    @show_config.error
    @ticketpanel.error
    async def ticket_admin_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, commands.MissingPermissions):
            await ctx.send(embed=embeds.error_embed("Missing Permissions", "You need the **Manage Server** permission to use this command."))
        elif isinstance(error, checks.PremiumRequired):
            await ctx.send(embed=embeds.premium_required_embed())
        else:
            raise error


async def setup(bot: commands.Bot) -> None:
    cog = Tickets(bot)
    await bot.add_cog(cog)
    # Register persistent views once, with static custom_ids, so every
    # button keeps working after a restart without needing the original
    # message object.
    bot.add_view(TicketPanelView(cog))
    bot.add_view(TicketControlView(cog))
    bot.add_view(ClosedTicketView(cog))
