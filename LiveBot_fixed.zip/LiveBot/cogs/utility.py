"""General utility commands: ping, serverinfo, userinfo, avatar, uptime."""
from __future__ import annotations

import datetime
import time
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import checks
import embeds


class Utility(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.start_time = datetime.datetime.now(datetime.timezone.utc)

    @commands.hybrid_command(name="ping", description="Check LiveBot's latency and connection status.")
    @checks.premium_required()
    async def ping(self, ctx: commands.Context) -> None:
        start = time.perf_counter()
        message = await ctx.send(embed=embeds.info_embed("🏓 Pinging..."))
        elapsed_ms = (time.perf_counter() - start) * 1000
        embed = embeds.info_embed(
            "🏓 Pong!",
            f"**Websocket latency:** {self.bot.latency * 1000:.0f}ms\n"
            f"**Message round-trip:** {elapsed_ms:.0f}ms\n"
            f"**Status:** Online ✅",
        )
        await message.edit(embed=embed)

    @commands.hybrid_command(name="serverinfo", description="Show information about this server.")
    @checks.premium_required()
    async def serverinfo(self, ctx: commands.Context) -> None:
        guild = ctx.guild
        assert guild is not None
        embed = embeds.info_embed(f"📊 {guild.name}")
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=f"<@{guild.owner_id}>", inline=True)
        embed.add_field(name="Members", value=str(guild.member_count), inline=True)
        embed.add_field(name="Created", value=f"<t:{int(guild.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Text Channels", value=str(len(guild.text_channels)), inline=True)
        embed.add_field(name="Voice Channels", value=str(len(guild.voice_channels)), inline=True)
        embed.add_field(name="Roles", value=str(len(guild.roles)), inline=True)
        embed.add_field(name="Boost Level", value=f"Level {guild.premium_tier}", inline=True)
        embed.add_field(name="Server ID", value=str(guild.id), inline=True)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="userinfo", description="Show information about a user.")
    @app_commands.describe(member="The user to look up (defaults to you)")
    @checks.premium_required()
    async def userinfo(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        target = member or ctx.author
        embed = embeds.info_embed(f"👤 {target.display_name}")
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="Username", value=str(target), inline=True)
        embed.add_field(name="User ID", value=str(target.id), inline=True)
        embed.add_field(name="Bot?", value="Yes" if target.bot else "No", inline=True)
        embed.add_field(name="Account Created", value=f"<t:{int(target.created_at.timestamp())}:D>", inline=True)
        if isinstance(target, discord.Member) and target.joined_at:
            embed.add_field(name="Joined Server", value=f"<t:{int(target.joined_at.timestamp())}:D>", inline=True)
            roles = [role.mention for role in reversed(target.roles) if role.name != "@everyone"]
            embed.add_field(
                name=f"Roles ({len(roles)})",
                value=", ".join(roles[:10]) if roles else "None",
                inline=False,
            )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="avatar", description="Display a user's avatar.")
    @app_commands.describe(member="The user whose avatar to show (defaults to you)")
    @checks.premium_required()
    async def avatar(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        target = member or ctx.author
        embed = embeds.info_embed(f"🖼️ {target.display_name}'s Avatar")
        embed.set_image(url=target.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="uptime", description="Show how long LiveBot has been online.")
    @checks.premium_required()
    async def uptime(self, ctx: commands.Context) -> None:
        delta = datetime.datetime.now(datetime.timezone.utc) - self.start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        await ctx.send(embed=embeds.info_embed("⏱️ Uptime", f"{days}d {hours}h {minutes}m {seconds}s"))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Utility(bot))
