"""
LiveBot entry point.

Connects the database, loads every cog, registers persistent ticket views,
syncs slash commands, and centralises error handling for anything that
isn't already handled by a more specific handler (so Premium enforcement
and permission errors always produce one consistent, professional reply).
"""
from __future__ import annotations

import asyncio
import logging

import discord
from discord.ext import commands
from discord import app_commands

import checks
import config
import embeds
from database import Database

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("livebot")

INITIAL_EXTENSIONS = (
    "cogs.premium",
    "cogs.tickets",
    "cogs.help_menu",
    "cogs.utility",
)


class LiveBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True

        super().__init__(
            command_prefix=commands.when_mentioned_or(config.PREFIX),
            intents=intents,
            owner_ids=set(config.OWNER_IDS),
            activity=discord.Activity(type=discord.ActivityType.watching, name=config.ACTIVITY_TEXT),
            help_command=None,  # replaced by the custom interactive help menu in cogs/help_menu.py
        )
        self.db = Database(config.DATABASE_PATH)

    async def setup_hook(self) -> None:
        await self.db.connect()
        logger.info("Database connected at %s", config.DATABASE_PATH)

        # Fail fast if a required cog cannot load. Starting a partially
        # functional bot can silently omit Premium enforcement or ticket tools.
        loaded_extensions: list[str] = []
        try:
            for extension in INITIAL_EXTENSIONS:
                await self.load_extension(extension)
                loaded_extensions.append(extension)
                logger.info("Loaded extension: %s", extension)
        except Exception:
            logger.exception("Required extension failed to load: %s", extension)
            # Best-effort cleanup so a failed startup does not leave a half-loaded bot.
            for loaded_extension in reversed(loaded_extensions):
                try:
                    await self.unload_extension(loaded_extension)
                except Exception:
                    logger.exception("Failed to unload extension during startup cleanup: %s", loaded_extension)
            await self.db.close()
            raise

        if config.DEV_GUILD_ID:
            guild = discord.Object(id=config.DEV_GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            logger.info("Synced %d app command(s) to dev guild %s", len(synced), config.DEV_GUILD_ID)
        else:
            synced = await self.tree.sync()
            logger.info("Synced %d app command(s) globally (may take up to 1 hour to propagate)", len(synced))

    async def on_ready(self) -> None:
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=config.ACTIVITY_TEXT)
        )
        logger.info("Logged in as %s (ID: %s)", self.user, self.user.id if self.user else "unknown")
        logger.info("Serving %d guild(s)", len(self.guilds))

    async def close(self) -> None:
        await self.db.close()
        await super().close()


bot = LiveBot()


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError) -> None:
    # Don't double-reply if the command (or its cog) already handled this.
    if ctx.command is not None and ctx.command.has_error_handler():
        return

    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, checks.PremiumRequired):
        await ctx.send(embed=embeds.premium_required_embed())
        return
    if isinstance(error, commands.NotOwner):
        await ctx.send(embed=embeds.error_embed("Owner Only", "Only the LiveBot owner can use this command."))
        return
    if isinstance(error, commands.MissingPermissions):
        missing = ", ".join(error.missing_permissions)
        await ctx.send(embed=embeds.error_embed("Missing Permissions", f"You need: `{missing}`"))
        return
    if isinstance(error, commands.NoPrivateMessage):
        await ctx.send(embed=embeds.error_embed("Server Only", str(error)))
        return
    if isinstance(error, (commands.BadArgument, commands.MissingRequiredArgument)):
        await ctx.send(embed=embeds.error_embed("Invalid Usage", str(error)))
        return
    if isinstance(error, commands.CommandOnCooldown):
        await ctx.send(embed=embeds.error_embed("Slow Down", f"Try again in {error.retry_after:.1f}s."))
        return

    logger.exception("Unhandled command error in %r", ctx.command, exc_info=error)
    await ctx.send(embed=embeds.error_embed("Something Went Wrong", "An unexpected error occurred. This has been logged."))


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
    """Return safe, consistent errors for slash-command failures."""
    original = getattr(error, "original", error)
    if isinstance(original, checks.PremiumRequired):
        embed = embeds.premium_required_embed()
    elif isinstance(original, commands.NotOwner):
        embed = embeds.error_embed("Owner Only", "Only the LiveBot owner can use this command.")
    elif isinstance(original, app_commands.MissingPermissions):
        embed = embeds.error_embed("Missing Permissions", "You need the required server permissions to use this command.")
    elif isinstance(original, app_commands.NoPrivateMessage):
        embed = embeds.error_embed("Server Only", "This command can only be used inside a server.")
    elif isinstance(original, app_commands.CommandOnCooldown):
        embed = embeds.error_embed("Slow Down", f"Try again in {original.retry_after:.1f}s.")
    else:
        logger.error("Unhandled application command error", exc_info=original)
        embed = embeds.error_embed("Something Went Wrong", "An unexpected error occurred. This has been logged.")

    try:
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, ephemeral=True)
    except discord.HTTPException:
        logger.debug("Could not send slash-command error response", exc_info=True)


@bot.command(name="sync")
@commands.is_owner()
async def sync_commands(ctx: commands.Context) -> None:
    """Owner-only: force a slash command re-sync (handy right after startup)."""
    synced = await bot.tree.sync()
    await ctx.send(embed=embeds.success_embed("Commands Synced", f"Synced {len(synced)} application command(s)."))


def main() -> None:
    config.validate()
    asyncio.run(bot.start(config.TOKEN))


if __name__ == "__main__":
    main()
