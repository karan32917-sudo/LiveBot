"""
Persistent SQLite storage for LiveBot.

Covers Premium subscriptions, ticket configuration and ticket records.
Uses aiosqlite so database calls never block the bot's event loop, and uses
`CREATE TABLE IF NOT EXISTS` plus `UPDATE`/`UPSERT` statements exclusively —
restarting the bot, or re-running setup commands, never destroys existing
records.
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass
from typing import List, Optional, Sequence

import aiosqlite


def _utcnow_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


@dataclass
class PremiumRecord:
    guild_id: int
    plan: str
    activated_at: str
    expires_at: Optional[str]
    activated_by: int
    active: bool

    @property
    def is_lifetime(self) -> bool:
        return self.expires_at is None

    @property
    def is_expired(self) -> bool:
        if self.is_lifetime:
            return False
        expires = datetime.datetime.fromisoformat(self.expires_at)
        return datetime.datetime.now(datetime.timezone.utc) >= expires


@dataclass
class Ticket:
    ticket_id: int
    guild_id: int
    channel_id: int
    user_id: int
    ticket_type: str
    status: str
    claimed_by: Optional[int]
    created_at: str
    closed_at: Optional[str]
    closed_by: Optional[int]


class Database:
    def __init__(self, path: str):
        self.path = path
        self._conn: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL;")
        await self._conn.execute("PRAGMA foreign_keys=ON;")
        await self._create_tables()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database.connect() must be awaited before use.")
        return self._conn

    async def _create_tables(self) -> None:
        await self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS premium_guilds (
                guild_id INTEGER PRIMARY KEY,
                plan TEXT NOT NULL,
                activated_at TEXT NOT NULL,
                expires_at TEXT,
                activated_by INTEGER NOT NULL,
                active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS ticket_config (
                guild_id INTEGER PRIMARY KEY,
                category_id INTEGER,
                log_channel_id INTEGER,
                transcript_channel_id INTEGER,
                support_role_ids TEXT NOT NULL DEFAULT '',
                panel_channel_id INTEGER,
                panel_message_id INTEGER,
                ticket_counter INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL UNIQUE,
                user_id INTEGER NOT NULL,
                ticket_type TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                claimed_by INTEGER,
                created_at TEXT NOT NULL,
                closed_at TEXT,
                closed_by INTEGER
            );
            """
        )
        await self.conn.commit()

    # ------------------------------------------------------------------
    # Premium
    # ------------------------------------------------------------------

    async def grant_premium(
        self, guild_id: int, plan: str, granted_by: int, days: Optional[int]
    ) -> PremiumRecord:
        now = datetime.datetime.now(datetime.timezone.utc)
        expires_at = None if days is None else (now + datetime.timedelta(days=days)).isoformat()
        await self.conn.execute(
            """
            INSERT INTO premium_guilds (guild_id, plan, activated_at, expires_at, activated_by, active)
            VALUES (?, ?, ?, ?, ?, 1)
            ON CONFLICT(guild_id) DO UPDATE SET
                plan=excluded.plan,
                activated_at=excluded.activated_at,
                expires_at=excluded.expires_at,
                activated_by=excluded.activated_by,
                active=1
            """,
            (guild_id, plan, now.isoformat(), expires_at, granted_by),
        )
        await self.conn.commit()
        record = await self.get_premium(guild_id)
        assert record is not None
        return record

    async def extend_premium(self, guild_id: int, days: int) -> Optional[PremiumRecord]:
        record = await self.get_premium(guild_id)
        if record is None:
            return None
        now = datetime.datetime.now(datetime.timezone.utc)
        if record.is_lifetime:
            new_expiry = None
        else:
            base = datetime.datetime.fromisoformat(record.expires_at)
            if base < now:
                base = now
            new_expiry = (base + datetime.timedelta(days=days)).isoformat()
        await self.conn.execute(
            "UPDATE premium_guilds SET expires_at = ?, active = 1 WHERE guild_id = ?",
            (new_expiry, guild_id),
        )
        await self.conn.commit()
        return await self.get_premium(guild_id)

    async def revoke_premium(self, guild_id: int) -> bool:
        cursor = await self.conn.execute(
            "UPDATE premium_guilds SET active = 0 WHERE guild_id = ?", (guild_id,)
        )
        await self.conn.commit()
        return cursor.rowcount > 0

    async def get_premium(self, guild_id: int) -> Optional[PremiumRecord]:
        async with self.conn.execute(
            "SELECT * FROM premium_guilds WHERE guild_id = ?", (guild_id,)
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return self._row_to_premium(row)

    async def is_premium(self, guild_id: int) -> bool:
        record = await self.get_premium(guild_id)
        if record is None or not record.active:
            return False
        if record.is_expired:
            # Auto-deactivate expired subscriptions.
            await self.conn.execute(
                "UPDATE premium_guilds SET active = 0 WHERE guild_id = ?", (guild_id,)
            )
            await self.conn.commit()
            return False
        return True

    async def all_premium_guilds(self) -> Sequence[PremiumRecord]:
        """Return only currently valid Premium records.

        Expired subscriptions are deactivated in SQLite before the records are
        returned, so owner-facing listings cannot show expired plans as active.
        Lifetime plans have expires_at=NULL and remain active until revoked.
        """
        now = _utcnow_iso()
        await self.conn.execute(
            """UPDATE premium_guilds
               SET active = 0
               WHERE active = 1
                 AND expires_at IS NOT NULL
                 AND expires_at <= ?""",
            (now,),
        )
        await self.conn.commit()
        async with self.conn.execute(
            "SELECT * FROM premium_guilds WHERE active = 1 ORDER BY activated_at DESC"
        ) as cursor:
            rows = await cursor.fetchall()
        return [self._row_to_premium(row) for row in rows]

    @staticmethod
    def _row_to_premium(row: aiosqlite.Row) -> PremiumRecord:
        return PremiumRecord(
            guild_id=row["guild_id"],
            plan=row["plan"],
            activated_at=row["activated_at"],
            expires_at=row["expires_at"],
            activated_by=row["activated_by"],
            active=bool(row["active"]),
        )

    # ------------------------------------------------------------------
    # Ticket configuration
    # ------------------------------------------------------------------

    async def get_ticket_config(self, guild_id: int) -> aiosqlite.Row:
        await self.conn.execute(
            "INSERT OR IGNORE INTO ticket_config (guild_id) VALUES (?)", (guild_id,)
        )
        await self.conn.commit()
        async with self.conn.execute(
            "SELECT * FROM ticket_config WHERE guild_id = ?", (guild_id,)
        ) as cursor:
            row = await cursor.fetchone()
        assert row is not None
        return row

    async def set_ticket_category(self, guild_id: int, category_id: int) -> None:
        await self.get_ticket_config(guild_id)
        await self.conn.execute(
            "UPDATE ticket_config SET category_id = ? WHERE guild_id = ?", (category_id, guild_id)
        )
        await self.conn.commit()

    async def set_log_channel(self, guild_id: int, channel_id: int) -> None:
        await self.get_ticket_config(guild_id)
        await self.conn.execute(
            "UPDATE ticket_config SET log_channel_id = ? WHERE guild_id = ?", (channel_id, guild_id)
        )
        await self.conn.commit()

    async def set_transcript_channel(self, guild_id: int, channel_id: int) -> None:
        await self.get_ticket_config(guild_id)
        await self.conn.execute(
            "UPDATE ticket_config SET transcript_channel_id = ? WHERE guild_id = ?",
            (channel_id, guild_id),
        )
        await self.conn.commit()

    async def add_support_role(self, guild_id: int, role_id: int) -> None:
        row = await self.get_ticket_config(guild_id)
        roles = self.parse_role_ids(row["support_role_ids"])
        if role_id not in roles:
            roles.append(role_id)
        await self.conn.execute(
            "UPDATE ticket_config SET support_role_ids = ? WHERE guild_id = ?",
            (",".join(str(r) for r in roles), guild_id),
        )
        await self.conn.commit()

    async def remove_support_role(self, guild_id: int, role_id: int) -> None:
        row = await self.get_ticket_config(guild_id)
        roles = [r for r in self.parse_role_ids(row["support_role_ids"]) if r != role_id]
        await self.conn.execute(
            "UPDATE ticket_config SET support_role_ids = ? WHERE guild_id = ?",
            (",".join(str(r) for r in roles), guild_id),
        )
        await self.conn.commit()

    @staticmethod
    def parse_role_ids(raw: str) -> List[int]:
        if not raw:
            return []
        return [int(value) for value in raw.split(",") if value.strip().isdigit()]

    async def set_panel_message(self, guild_id: int, channel_id: int, message_id: int) -> None:
        await self.get_ticket_config(guild_id)
        await self.conn.execute(
            "UPDATE ticket_config SET panel_channel_id = ?, panel_message_id = ? WHERE guild_id = ?",
            (channel_id, message_id, guild_id),
        )
        await self.conn.commit()

    async def next_ticket_number(self, guild_id: int) -> int:
        await self.get_ticket_config(guild_id)
        await self.conn.execute(
            "UPDATE ticket_config SET ticket_counter = ticket_counter + 1 WHERE guild_id = ?",
            (guild_id,),
        )
        await self.conn.commit()
        async with self.conn.execute(
            "SELECT ticket_counter FROM ticket_config WHERE guild_id = ?", (guild_id,)
        ) as cursor:
            row = await cursor.fetchone()
        assert row is not None
        return row["ticket_counter"]

    # ------------------------------------------------------------------
    # Tickets
    # ------------------------------------------------------------------

    async def create_ticket(
        self, guild_id: int, channel_id: int, user_id: int, ticket_type: str
    ) -> Ticket:
        await self.conn.execute(
            """
            INSERT INTO tickets (guild_id, channel_id, user_id, ticket_type, status, created_at)
            VALUES (?, ?, ?, ?, 'open', ?)
            """,
            (guild_id, channel_id, user_id, ticket_type, _utcnow_iso()),
        )
        await self.conn.commit()
        ticket = await self.get_ticket_by_channel(channel_id)
        assert ticket is not None
        return ticket

    async def get_ticket_by_channel(self, channel_id: int) -> Optional[Ticket]:
        async with self.conn.execute(
            "SELECT * FROM tickets WHERE channel_id = ?", (channel_id,)
        ) as cursor:
            row = await cursor.fetchone()
        return self._row_to_ticket(row) if row else None

    async def get_open_ticket_for_user(
        self, guild_id: int, user_id: int, ticket_type: str
    ) -> Optional[Ticket]:
        async with self.conn.execute(
            """
            SELECT * FROM tickets
            WHERE guild_id = ? AND user_id = ? AND ticket_type = ? AND status != 'closed'
            """,
            (guild_id, user_id, ticket_type),
        ) as cursor:
            row = await cursor.fetchone()
        return self._row_to_ticket(row) if row else None

    async def claim_ticket(self, channel_id: int, staff_id: int) -> None:
        await self.conn.execute(
            "UPDATE tickets SET status = 'claimed', claimed_by = ? WHERE channel_id = ?",
            (staff_id, channel_id),
        )
        await self.conn.commit()

    async def unclaim_ticket(self, channel_id: int) -> None:
        await self.conn.execute(
            "UPDATE tickets SET status = 'open', claimed_by = NULL WHERE channel_id = ?",
            (channel_id,),
        )
        await self.conn.commit()

    async def close_ticket(self, channel_id: int, closed_by: int) -> None:
        await self.conn.execute(
            "UPDATE tickets SET status = 'closed', closed_at = ?, closed_by = ? WHERE channel_id = ?",
            (_utcnow_iso(), closed_by, channel_id),
        )
        await self.conn.commit()

    async def reopen_ticket(self, channel_id: int) -> None:
        await self.conn.execute(
            "UPDATE tickets SET status = 'open', closed_at = NULL, closed_by = NULL WHERE channel_id = ?",
            (channel_id,),
        )
        await self.conn.commit()

    @staticmethod
    def _row_to_ticket(row: aiosqlite.Row) -> Ticket:
        return Ticket(
            ticket_id=row["ticket_id"],
            guild_id=row["guild_id"],
            channel_id=row["channel_id"],
            user_id=row["user_id"],
            ticket_type=row["ticket_type"],
            status=row["status"],
            claimed_by=row["claimed_by"],
            created_at=row["created_at"],
            closed_at=row["closed_at"],
            closed_by=row["closed_by"],
        )
